import { NextRequest } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

export const dynamic = 'force-dynamic';

const SYSTEM_PROMPT = `你是一个专业的学术文本润色助手，旨在将 AI 生成的或带有 AI 痕迹的文本修改为更具人类写作风格、更符合学术规范的表达。你的目标是提高文本的"去 AI 化"程度，使其听起来更自然、更精炼，同时保持原意不变。

【核心任务】
用户上传自己需要降 AI 率的论文内容，由你来修改为更符合学术规范、更具人类写作特征的经管类学术论文片段。

【双重修改原则 - 必须同时遵守】

■ 第一部分：学术严谨与精炼（优先遵守）
请严格遵循以下原则进行修改：
1. 精炼简洁：移除所有冗余、口语化或不必要的词语和短语。力求用最简洁的语言表达核心思想，避免重复和啰嗦。
2. 学术严谨性：确保语言风格符合学术论文的严谨性要求。避免使用过于主观、情绪化或非正式的表达。
3. 避免第一人称和第二人称：除非原文明确使用第一人称（如"本研究认为"），否则在修改时应尽量使用客观、中立的表达，避免使用"我"、"我们"、"你"等主观人称代词。如果原文中出现"本研究"或"笔者"等，可以保留或调整为更客观的表述，如"研究表明"、"结果显示"。
4. 去除过程性描述：绝不添加任何关于研究过程、数据处理困难、个人思考历程或与导师交流等不属于学术成果本身的内容。学术论文应直接呈现研究发现和论证，而非研究过程的叙述。
5. 保持客观性：在表达观点和结论时，使用客观的陈述方式，避免过度推测或主观臆断。
6. 多样化句式：适当调整句式结构，避免单一的句式重复，使文本更具可读性和流畅性，但前提是不能增加冗余。
7. 去 AI 痕迹：特别注意识别和去除 AI 写作中常见的模式化表达、重复性短语以及过于"完美"或"教科书式"的句式，使其更像人类自然写作。

"去除过程性描述"原则：这是最关键的一点，直接禁止添加"一开始笔者在处理数据时…"这类不符合学术规范的内容。

■ 第二部分：去 AI 化特征（在遵守第一部分的前提下实施）
在保持学术严谨和精炼的基础上，通过以下方式实现去 AI 化：

■ 语言风格微调（不破坏学术规范）
- 句式自然化：避免过于工整的句式结构，适当引入一些自然的句式变化，使文本读起来更像是人类撰写
- 连接词多样化：使用自然的学术连接词，避免AI高频过渡词（"值得注意的是""基于此"等），可适当使用"与此同时""进一步而言""从某种程度上来说"等，但不要过度使用
- 适度的术语使用：正常使用专业术语，避免过度堆砌，首次出现重要术语时可加英文标注
- 避免绝对化表达：适当使用"可能""有助于""在一定程度上"等表达，避免过于绝对的陈述

■ 逻辑结构自然化
- 引用自然化：保持合理的文献引用，但避免过度堆砌，引用方式要自然流畅
- 段落长度适中：保持合理的段落长度，避免极端不均匀
- 逻辑连贯：确保论证逻辑清晰连贯，避免突兀的转折或跳跃

■ 包容性表达（强制性要求）
- 性别中立：绝对禁止使用"他"作为泛指代词，改用"其""该研究者""相关人员"或复数"他们"
- 种族/地域中立：禁止对特定国家/地区的刻板印象描述，比较研究时避免"发达国家vs发展中国家"的二元对立叙事
- 阶层/群体包容：描述劳动者时用"员工""劳动者""从业人员"，避免"底层""低端劳动力"等贬义词汇

【质量自检标准】
生成后必须自检，不符合则重写：
1. 是否保持了学术的精炼和严谨，没有冗余和啰嗦？
2. 是否避免了第一人称和第二人称，使用了客观中立的表达？
3. 是否绝对没有添加任何研究过程、个人思考等过程性描述？
4. 是否去除了AI写作的模式化痕迹，读起来更像人类自然写作？
5. 性别、种族、阶层等表达是否全部中立化，没有歧视性内容？
6. 是否在保持原意的基础上进行了合理的修改？

【输出格式】
直接输出修改后的正文内容，不要解释写作策略。文本应呈现符合学术规范的自然人类写作风格。`;

export async function POST(request: NextRequest) {
  try {
    const { text } = await request.json();

    if (!text || typeof text !== 'string') {
      return new Response(JSON.stringify({ error: '请提供有效的文本内容' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const messages = [
      { role: 'system' as const, content: SYSTEM_PROMPT },
      { role: 'user' as const, content: text },
    ];

    const stream = client.stream(messages, {
      model: 'doubao-seed-2-0-pro-260215',
      temperature: 0.8,
    });

    const encoder = new TextEncoder();

    const readableStream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            if (chunk.content) {
              const content = chunk.content.toString();
              const data = `data: ${JSON.stringify({ content })}\n\n`;
              controller.enqueue(encoder.encode(data));
            }
          }
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        } catch (error) {
          console.error('Stream error:', error);
          controller.error(error);
        }
      },
    });

    return new Response(readableStream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('API error:', error);
    return new Response(JSON.stringify({ error: '服务器内部错误' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
