import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '论文降AI助手 | 让你的AI写作更像学生',
    template: '%s | 论文降AI助手',
  },
  description:
    '帮助降低论文写作时的AIGC生成率，将AI生成的内容修改为带有明显"学生习作"特征的经管类学术论文。',
  keywords: [
    '论文降AI',
    'AI检测',
    '学生论文',
    '学术写作',
    '论文修改',
    'Turnitin',
    '知网检测',
  ],
  authors: [{ name: 'Paper Assistant Team' }],
  generator: 'Coze Code',
  openGraph: {
    title: '论文降AI助手 | 让你的AI写作更像学生',
    description:
      '帮助降低论文写作时的AIGC生成率，将AI生成的内容修改为带有明显"学生习作"特征的经管类学术论文。',
    locale: 'zh_CN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="zh-CN">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.cn" />
        <link rel="preconnect" href="https://fonts.gstatic.cn" crossOrigin="" />
        <link href="https://fonts.googleapis.cn/css2?family=Lora:ital,wght@0,400;0,500;0,600;1,400&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
