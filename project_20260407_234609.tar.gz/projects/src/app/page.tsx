'use client';

import { useState, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy, RotateCcw, Check, FileText } from 'lucide-react';

export default function Home() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [error, setError] = useState('');
  const outputRef = useRef<HTMLDivElement>(null);

  const handleSubmit = useCallback(async () => {
    if (!inputText.trim()) {
      setError('请输入需要降AI率的论文内容');
      return;
    }

    setIsLoading(true);
    setError('');
    setOutputText('');

    try {
      const response = await fetch('/api/rewrite', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: inputText }),
      });

      if (!response.ok) {
        throw new Error('请求失败');
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('无法获取响应流');
      }

      const decoder = new TextDecoder();
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;
            try {
              const parsed = JSON.parse(data);
              if (parsed.content) {
                fullText += parsed.content;
                setOutputText(fullText);
              }
            } catch {
              // 忽略解析错误
            }
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '发生未知错误');
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);

  const handleCopy = useCallback(() => {
    if (!outputText) return;
    navigator.clipboard.writeText(outputText).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    });
  }, [outputText]);

  const handleReset = useCallback(() => {
    setInputText('');
    setOutputText('');
    setError('');
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="flex items-center gap-3 mb-2">
            <FileText className="w-8 h-8 text-primary" />
            <h1 className="text-2xl font-semibold font-sans text-foreground">
              论文降AI助手
            </h1>
          </div>
          <p className="text-muted-foreground text-sm">
            专业学术文本润色，去除AI痕迹，保持学术严谨
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium font-sans text-foreground">
                输入原文
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleReset}
                className="text-muted-foreground hover:text-foreground"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                清空
              </Button>
            </div>
            <Card className="p-4">
              <Textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="在此粘贴需要降AI率的论文内容..."
                className="min-h-[400px] resize-none border-none focus-visible:ring-0 p-0 text-sm leading-relaxed"
              />
            </Card>
          </div>

          {/* Output Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium font-sans text-foreground">
                修改结果
              </h2>
              {outputText && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopy}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-1" />
                      复制
                    </>
                  )}
                </Button>
              )}
            </div>
            <Card className="p-4 min-h-[448px]">
              <ScrollArea className="h-[400px] pr-4">
                <div ref={outputRef} className="text-sm leading-relaxed text-foreground">
                  {isLoading && !outputText && (
                    <div className="text-muted-foreground animate-pulse">
                      正在修改中...
                    </div>
                  )}
                  {!isLoading && !outputText && !error && (
                    <div className="text-muted-foreground">
                      点击下方按钮开始修改
                    </div>
                  )}
                  {outputText && (
                    <div className="whitespace-pre-wrap">{outputText}</div>
                  )}
                </div>
              </ScrollArea>
            </Card>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <p className="text-destructive text-sm">{error}</p>
          </div>
        )}

        {/* Submit Button */}
        <div className="mt-8 flex justify-center">
          <Button
            onClick={handleSubmit}
            disabled={isLoading || !inputText.trim()}
            className="px-8 py-6 text-base bg-primary hover:bg-primary/90"
          >
            {isLoading ? '修改中...' : '开始降AI'}
          </Button>
        </div>

        {/* Instructions */}
        <div className="mt-12 pt-8 border-t border-border">
          <h3 className="text-sm font-medium font-sans text-foreground mb-3">
            使用说明
          </h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• 将AI生成的论文内容粘贴到左侧输入框</li>
            <li>• 点击开始降AI按钮，系统会去除AI痕迹并优化文本表达</li>
            <li>• 保持学术严谨性，移除冗余、口语化和过程性描述</li>
            <li>• 修改后的内容会以打字机效果实时显示在右侧</li>
            <li>• 支持复制功能，方便直接使用</li>
          </ul>
        </div>
      </main>
    </div>
  );
}
